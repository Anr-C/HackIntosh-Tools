# El Capitan Login Theme

El Capitan Login Theme for [clover hackintosh](http://sourceforge.net/projects/cloverefiboot/).  Continuation of xenatt's Yosemite Login theme from the [clover theme database] (http://clover-wiki.zetam.org/theme-database).

![screen shot](https://raw.githubusercontent.com/jrnewell/el-capitan-login/master/screenshot.png)

I also added more linux distrubtion icons mainly from the Aha-Soft Team [icon set] (https://www.iconfinder.com/iconsets/flat-round-system).

## License

[MIT License](http://en.wikipedia.org/wiki/MIT_License)
